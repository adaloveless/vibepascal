# vibepascal Win64 Cross-Built Drop (v6)

Cross-compiled from `lazdev` (Linux x86_64) using FPC's internal PE-COFF
assembler + internal linker. **No mingw-w64 or external binutils required
on the host.** All binaries statically link RTL -- only kernel32.dll and
user32.dll are imported for typical code (oleaut32.dll when variants are
pulled in; ole32.dll when activex/COM is pulled in). Per God's
preference (dashboard mo35bv5w): large self-contained EXEs, not
dependency forests.

## What's new in v6 vs v5
v6 bundles a freshly-cross-built `ppcx64.exe` that includes two compiler
changes landed since v5:

- **`m_inline_var` enabled in `{$mode delphi}`** (commit 41ff4a2b03).
  Delphi-compat inline variable declarations -- both `for var X := A to
  B do` and statement-level `var X := expr;` -- now parse under
  `{$mode delphi}` out of the box. Previously this was gated behind
  `m_inline_var` which lived only in `unleashedmodeswitches`. Unblocks
  ~3,450 occurrences across 250+ files in FPC_commonx.

- **`{$INLINE AUTO}` accepted as Delphi-compat alias** for `{$INLINE ON}`
  (commit fe2849d7a7). `dir_inline` in `compiler/scandir.pas` now
  explicitly parses ON / OFF / + / - / AUTO (AUTO -> ON, since FPC's
  `cs_do_inline` already gates marked-function inlining).

PPU files (units/, packages/) are byte-identical to v5 -- compiler
version string unchanged at "FPC 3.3.1 [2026/04/17]", so v5's PPUs load
cleanly under v6's ppcx64.exe. Only the compiler binary needed refresh.

## Contents
- `bin/ppcx64.exe` -- Win64-native vibepascal compiler (FPC 3.3.1
  [2026/04/17], PE32+, ~5.0MB). **NEW for v6**: inline_var under
  {$mode delphi} + {$INLINE AUTO}.
- `units/x86_64-win64/*.ppu` + `*.o` -- Win64 RTL (90 units).
- `packages/rtl-objpas/x86_64-win64/` -- variants, varutils, rtti,
  system.timespan, dateutils, strutils, sysconst, character, fmtbcd.
- `packages/rtl-generics/x86_64-win64/` -- generics.{collections,
  defaults, helpers, hashes, memoryexpanders, strings}.
- `packages/fcl-base/x86_64-win64/` -- contnrs, syncobjs, inifiles.
- `packages/rtl-extra/x86_64-win64/` -- objects.
- `packages/winunits-base/x86_64-win64/` -- tlhelp32, activex.

## Known gap for Knox's v6 shopping list
Knox's HIGH-priority winapi unit requests (winsock, winsock2, shellapi,
shlobj, shfolder, winsvc, psapi, imagehlp, iptypes, mmsystem, userenv)
are **not yet pre-built** in this drop. Most of their source files exist
under `packages/winunits-base/src/` and `packages/rtl-extra/src/win/`
(see vibepascal tree) and can be cross-built ad-hoc with the same
ppcx64 -Apecoff -Xi -Twin64 recipe. A dedicated v7 drop will ship them
pre-built on the next cycle.

## Source snapshot
- Repo: `github.com/adaloveless/vibepascal`
- Branch: `main`, commit `41ff4a2b03`.

## Usage on Windows
Extract alongside your FPC installation, e.g. `C:\vibepascal\`. Then:

```
C:\vibepascal\bin\ppcx64.exe ^
  -Fu"C:\vibepascal\units\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\rtl-objpas\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\rtl-generics\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\fcl-base\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\rtl-extra\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\winunits-base\x86_64-win64" ^
  -Mdelphi stringx.pas
```

## Static linking
All resulting `.exe` binaries (including `ppcx64.exe` itself) statically
link the FPC RTL. No FPC DLL runtime dependencies -- only Windows system
DLLs are imported (kernel32, user32; oleaut32 + ole32 when the consumer
pulls variants or activex).

## Build verification
Smoke test on `lazdev`: 14-line {$mode delphi} program with `for var i
:= 0 to High(arr) do` + `var msg := 'total=' + IntToStr(total);` ->
cross-compiled Win64 PE32+ with imports kernel32 + user32 only. Inline
var syntax confirmed working under {$mode delphi} without requiring
{$mode delphiunicode} or {$modeswitch inlinevars}.

## tlhelp32 choice of source
vibepascal ships TWO files named `tlhelp32`:

- `packages/winceunits/src/tlhelp32.pas` -- WinCE-only. Imports
  from `toolhelp.dll` (does not exist on desktop Windows), uses `cdecl`,
  `WCHAR` szExeFile. Do NOT use for Win64 desktop targets.
- `packages/winunits-base/src/tlhelp32.pp` -- **desktop Win32/Win64**.
  Imports from `kernel32.dll`, uses `stdcall`, provides ANSI + W variants.
  **This is what the v6 tarball's `tlhelp32.ppu` is built from.**

When you add the winunits-base unit directory to `-Fu`, the compiler
picks up the desktop version. Do not add the winceunits directory to
your Win64 search path.
