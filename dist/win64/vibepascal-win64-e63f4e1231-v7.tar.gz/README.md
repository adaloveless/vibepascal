# vibepascal Win64 Cross-Built Drop (v7)

Cross-compiled from `lazdev` (Linux x86_64) using FPC's internal PE-COFF
assembler + internal linker. **No mingw-w64 or external binutils required
on the host.** All binaries statically link RTL -- only kernel32.dll and
user32.dll are imported for typical code (plus whatever the Win API unit
in question actually calls: ws2_32 for winsock, shell32 for shellapi,
advapi32 for winsvc, etc.). Per God's preference (dashboard mo35bv5w):
large self-contained EXEs, not dependency forests.

## What's new in v7 vs v6

v7 pre-ships Knox's HIGH-priority Win API unit shopping list. All 11
units from `from_Knox_2026-04-17_v5_status_and_v6_shopping_list.txt` are
now built for `x86_64-win64` and included in the tarball:

| Unit        | Source location                                 | Imports DLL          |
| ---         | ---                                             | ---                  |
| winsock     | packages/rtl-extra/src/win/winsock.pp           | ws2_32.dll           |
| winsock2    | packages/rtl-extra/src/win/winsock2.pp          | ws2_32.dll           |
| shellapi    | packages/winunits-base/src/shellapi.pp          | shell32.dll          |
| shlobj      | packages/winunits-base/src/shlobj.pp            | shell32.dll          |
| shfolder    | packages/winunits-base/src/shfolder.pp          | SHFolder.dll         |
| winsvc      | packages/winunits-base/src/winsvc.pp            | advapi32.dll         |
| psapi       | packages/winunits-base/src/psapi.pp             | psapi.dll            |
| imagehlp    | packages/winunits-base/src/imagehlp.pp          | imagehlp.dll         |
| iptypes     | packages/winunits-base/src/iptypes.pp           | (type defs only)     |
| mmsystem    | packages/winunits-base/src/mmsystem.pp          | winmm.dll            |
| userenv     | packages/winunits-base/src/userenv.pp           | userenv.dll          |

Compiler binary and existing PPUs are carried over unchanged from v6 --
only bin/ppcx64.exe from v6 + new winunits-base/rtl-extra PPUs here.
Version string still "FPC 3.3.1 [2026/04/17]" so the v6 compiler reads
these PPUs natively (no version mismatch).

v7 carries over from v6:
- `m_inline_var` under `{$mode delphi}` (41ff4a2b03)
- `{$INLINE AUTO}` Delphi-compat alias (fe2849d7a7)

## Contents
- `bin/ppcx64.exe` -- Win64-native vibepascal compiler (FPC 3.3.1
  [2026/04/17], PE32+, ~5.0MB). Unchanged from v6.
- `units/x86_64-win64/*.ppu` + `*.o` -- Win64 RTL (90 units).
- `packages/rtl-objpas/x86_64-win64/` -- variants, varutils, rtti,
  system.timespan, dateutils, strutils, sysconst, character, fmtbcd.
- `packages/rtl-generics/x86_64-win64/` -- generics.{collections,
  defaults, helpers, hashes, memoryexpanders, strings}.
- `packages/fcl-base/x86_64-win64/` -- contnrs, syncobjs, inifiles.
- `packages/rtl-extra/x86_64-win64/` -- objects, **winsock, winsock2**.
- `packages/winunits-base/x86_64-win64/` -- activex, tlhelp32, commctrl
  (dep of shlobj), **shellapi, shlobj, shfolder, winsvc, psapi,
  imagehlp, iptypes, mmsystem, userenv**.

## Source snapshot
- Repo: `github.com/adaloveless/vibepascal`
- Branch: `main`, commit tagged in filename.

## Usage on Windows
Extract alongside your FPC installation, e.g. `C:\vibepascal\`. Then:

```
C:\vibepascal\bin\ppcx64.exe ^
  -Fu"C:\vibepascal\units\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\rtl-objpas\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\rtl-generics\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\fcl-base\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\rtl-extra\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\winunits-base\x86_64-win64" ^
  -Mdelphi stringx.pas
```

## Static linking
All resulting `.exe` binaries (including `ppcx64.exe` itself) statically
link the FPC RTL. No FPC DLL runtime dependencies -- only Windows system
DLLs are imported, and only the ones actually referenced by the consumer
program.

## Build verification (v7)
11-unit smoke test on `lazdev`: single `.pas` consuming windows, winsock,
winsock2, shellapi, shlobj, shfolder, winsvc, psapi, imagehlp, iptypes,
mmsystem, userenv, tlhelp32 plus exercising entry points
(WSAStartup/Cleanup, SHGetFolderPath, ShellExecute, OpenSCManager,
EnumProcessModules, CreateToolhelp32Snapshot, timeGetTime,
MakeSureDirectoryPathExists) -> cross-compiled to 194KB PE32+ binary
with imports: kernel32, user32, advapi32, shell32, ws2_32, SHFolder,
psapi, imagehlp, winmm, oleaut32. No rogue DLLs (no toolhelp.dll, no
coredll.dll, no libgcc*), all vanilla Win32 redistributable.

## tlhelp32 choice of source
vibepascal ships TWO files named `tlhelp32`:

- `packages/winceunits/src/tlhelp32.pas` -- WinCE-only. Imports
  from `toolhelp.dll` (does not exist on desktop Windows), uses `cdecl`,
  `WCHAR` szExeFile. Do NOT use for Win64 desktop targets.
- `packages/winunits-base/src/tlhelp32.pp` -- **desktop Win32/Win64**.
  Imports from `kernel32.dll`, uses `stdcall`, provides ANSI + W variants.
  **This is what the v7 tarball's `tlhelp32.ppu` is built from.**

When you add the winunits-base unit directory to `-Fu`, the compiler
picks up the desktop version. Do not add the winceunits directory to
your Win64 search path.

## Cross-build recipe (reproducible on lazdev)
```
# winunits-base units (need variants for shellapi/shlobj's activex dep)
cd packages/winunits-base/src
ppcx64 -Apecoff -Xi -Twin64 \
  -Fu../../../rtl/units/x86_64-win64 \
  -Fu../../rtl-objpas/units/x86_64-win64 \
  -Fu../x86_64-win64 \
  -FU../x86_64-win64 \
  <unit>.pp

# rtl-extra win units
cd packages/rtl-extra/src/win
ppcx64 -Apecoff -Xi -Twin64 \
  -Fu../../../../rtl/units/x86_64-win64 \
  -FU../../x86_64-win64 \
  <unit>.pp
```
