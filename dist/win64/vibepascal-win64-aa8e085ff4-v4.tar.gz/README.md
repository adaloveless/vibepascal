# vibepascal Win64 Cross-Built Drop (v4)

Cross-compiled from `lazdev` (Linux x86_64) using FPC's internal PE-COFF
assembler + internal linker. **No mingw-w64 or external binutils required
on the host.** All binaries statically link RTL — only kernel32.dll and
user32.dll are imported for typical code (oleaut32.dll when variants are
pulled in). Per God's preference (dashboard mo35bv5w): large
self-contained EXEs, not dependency forests.

## Contents
- `bin/ppcx64.exe` — Win64-native vibepascal compiler (FPC 3.3.1
  [2026/04/14], PE32+, ~5.0MB).
- `units/x86_64-win64/*.ppu` + `*.o` — Win64 RTL (90 units, includes
  `sysconst` and `character`).
- `packages/rtl-objpas/x86_64-win64/` — variants, varutils, rtti,
  system.timespan, dateutils, strutils, **fmtbcd** (new in v4).
- `packages/rtl-generics/x86_64-win64/` — generics.{collections,
  defaults, helpers, hashes, memoryexpanders, strings}.
- `packages/fcl-base/x86_64-win64/` — contnrs, **syncobjs** (new in v4),
  **inifiles** (new in v4).
- `packages/rtl-extra/x86_64-win64/` — **objects** (new in v4).

## What's new in v4 vs v3
v4 adds four units requested by Knox (PascalDev_CommonX) for the
UT_Commonx regression against FPC_commonx:

- `syncobjs.ppu` — **hard blocker** (systemx.pas line 60 `uses syncobjs`);
  Delphi interface parity mandatory per God directive mo146ydp.
- `inifiles.ppu` — future-proofing (flagged as likely future dep).
- `fmtbcd.ppu` — completes the `v3_package_request.txt` shopping list.
- `objects.ppu` — future-proofing (rtl-extra Turbo Vision compat).

## Source snapshot
- Repo: `github.com/adaloveless/vibepascal`
- Branch: `main`, commit embedded in tarball filename
  (`vibepascal-win64-<sha>-v4.tar.gz`).

## Usage on Windows
Extract alongside your FPC installation, e.g. `C:\vibepascal\`. Then:

```
C:\vibepascal\bin\ppcx64.exe ^
  -Fu"C:\vibepascal\units\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\rtl-objpas\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\rtl-generics\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\fcl-base\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\rtl-extra\x86_64-win64" ^
  -Mdelphi stringx.pas
```

## Static linking
All resulting `.exe` binaries (including `ppcx64.exe` itself) statically
link the FPC RTL. There are no FPC DLL runtime dependencies — only
Windows system DLLs are imported (kernel32, user32; oleaut32 when the
consumer pulls variants).

## Reproducible build recipe (on Linux with vibepascal compiler)

```sh
RTLWIN=$PWD/rtl/units/x86_64-win64
OBJPAS=$PWD/packages/rtl-objpas/units/x86_64-win64
FCLBASE=$PWD/packages/fcl-base/units/x86_64-win64
RTLXTRA=$PWD/packages/rtl-extra/units/x86_64-win64
PPC=./compiler/ppcx64
COMMON="-Apecoff -Xi -Twin64"

# 1. RTL (from a clean native Linux cycle that built ./compiler/ppcx64)
make rtl_all CPU_TARGET=x86_64 OS_TARGET=win64 FPC=$PPC OPT="-Apecoff -Xi"

# 2. Win64-native compiler
cd compiler && make compiler CPU_TARGET=x86_64 OS_TARGET=win64 \
  FPC=./ppcx64 OPT="-Apecoff -Xi" && cd ..

# 3. rtl-objpas (fpmake cross-build broken — use direct ppcx64)
# See v2/v3 for varutils, variants, rtti, system.timespan, dateutils, strutils.
$PPC $COMMON -Fu$RTLWIN -Fu$OBJPAS -FU$OBJPAS \
  packages/rtl-objpas/src/inc/fmtbcd.pp

# 4. rtl-generics (unchanged from v2; see prior READMEs).

# 5. fcl-base (contnrs from v3; new in v4: syncobjs + inifiles)
mkdir -p $FCLBASE
$PPC $COMMON -Fu$RTLWIN -Fu$OBJPAS -Fu$FCLBASE -FU$FCLBASE \
  packages/fcl-base/src/syncobjs.pp
$PPC $COMMON -Fu$RTLWIN -Fu$OBJPAS -Fu$FCLBASE -FU$FCLBASE \
  packages/fcl-base/src/inifiles.pp

# 6. rtl-extra (new in v4: objects)
mkdir -p $RTLXTRA
$PPC $COMMON -Fu$RTLWIN -FU$RTLXTRA \
  packages/rtl-extra/src/inc/objects.pp
```

## Build verification
Smoke test on `lazdev` compiled a 38-line program consuming classes +
sysutils + contnrs + dateutils + strutils + syncobjs + inifiles +
fmtbcd. Result: 500KB PE32+ console exe, imports kernel32 + user32 +
oleaut32 only. Static-link confirmed.
