# vibepascal Win64 v8 drop

- TProc / TProc<T..T4>, TFunc<..TResult>, TPredicate<T> shipped in
  System.SysUtils (rtl/units/x86_64-win64/sysutils.ppu).
- Compiler: non-generic types can now coexist with same-named
  generic arity siblings in {$mode objfpc}+functionreferences.
- All dependent packages rebuilt against the new sysutils.ppu.
