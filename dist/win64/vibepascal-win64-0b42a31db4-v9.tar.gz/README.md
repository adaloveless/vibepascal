# vibepascal Win64 v9 drop (compiler-only refresh over v8)

Based on v8 (commit 41717f9142) with one compiler fix on top:

- Self-referential generic constraints under {$mode delphi} now parse,
  e.g. `TBar<T: IFoo<T>>` and commonx `TLinkedList<T: IIndirectlyLinkable<T>>`.
  Previously emitted "Identifier not found T" at the T inside IFoo<T>.

Scope: only `bin/ppcx64.exe` changed. All RTL/packages PPUs are byte-identical
to v8 because the FPC version string (3.3.1 [2026/04/17]) did not advance.
This is a drop-in compiler swap - unpack over v8 and you are done.

Carried forward from v8:
- TProc / TProc<T..T4>, TFunc<..TResult>, TPredicate<T> in System.SysUtils
- Compiler: non-generic and same-name generic arity siblings coexist under
  {$mode objfpc}+functionreferences.
