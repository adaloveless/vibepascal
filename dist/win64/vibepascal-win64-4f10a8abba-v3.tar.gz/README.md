# vibepascal Win64 Cross-Built Drop (v3)

Cross-compiled from `lazdev` (Linux x86_64) using FPC's internal PE-COFF
assembler + internal linker. **No mingw-w64 or external binutils required
on the host.** All binaries statically link RTL — only kernel32.dll and
user32.dll are imported (Windows system DLLs only).

## Contents
- `bin/ppcx64.exe` — Win64-native vibepascal compiler (FPC 3.3.1
  [2026/04/14], PE32+, ~5.0MB).
- `units/x86_64-win64/*.ppu` + `*.o` — Win64 RTL (90 units).
- `packages/rtl-objpas/x86_64-win64/` — variants, varutils, rtti,
  system.timespan, **dateutils** (new in v3), **strutils** (new in v3).
- `packages/rtl-generics/x86_64-win64/` — generics.{collections,
  defaults, helpers, hashes, memoryexpanders, strings}.
- `packages/fcl-base/x86_64-win64/` — **contnrs** (new in v3).

## What's new in v3 vs v2
v3 adds three units that `commonx/systemx.pas` and wider commonx code
pulls in:
- `dateutils.ppu` (hard blocker for systemx.pas line 30 — unguarded `uses
  dateutils`)
- `strutils.ppu` (commonly used by commonx string helpers)
- `contnrs.ppu` (legacy container lib — TObjectList etc.)

## Source snapshot
- Repo: `github.com/adaloveless/vibepascal`
- Branch: `main`, commit embedded in tarball filename.

## Usage on Windows
Extract alongside your FPC installation, e.g. `C:\vibepascal\`. Then:

```
C:\vibepascal\bin\ppcx64.exe ^
  -Fu"C:\vibepascal\units\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\rtl-objpas\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\rtl-generics\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\fcl-base\x86_64-win64" ^
  -Mdelphi stringx.pas
```

## Static linking
All resulting `.exe` binaries (including `ppcx64.exe` itself) statically
link the FPC RTL. There are no FPC DLL runtime dependencies — the only
imports are Windows system DLLs (kernel32, user32). Per God's
preference (dashboard mo35bv5w, 2026-04-17): we ship large self-contained
EXEs, not dependency forests.

## Reproducible build recipe (on Linux with vibepascal compiler)
```
RTLWIN=$PWD/rtl/units/x86_64-win64
OBJPAS=$PWD/packages/rtl-objpas/units/x86_64-win64
FCLBASE=$PWD/packages/fcl-base/units/x86_64-win64
PPC=./compiler/ppcx64
COMMON="-Apecoff -Xi -Twin64"

# 1. RTL
make rtl_all CPU_TARGET=x86_64 OS_TARGET=win64 FPC=$PPC \
  OPT="-Apecoff -Xi"

# 2. Win64-native compiler
cd compiler && make compiler CPU_TARGET=x86_64 OS_TARGET=win64 \
  FPC=./ppcx64 OPT="-Apecoff -Xi" && cd ..

# 3. rtl-objpas units (direct ppcx64 — fpmake cross-build broken)
$PPC $COMMON -Fu$RTLWIN -Fisrc/inc -Fisrc/win -FU$OBJPAS \
  packages/rtl-objpas/src/inc/varutils.pp        # wvarutil.inc from src/win
$PPC $COMMON -Fu$RTLWIN -Fu$OBJPAS -FU$OBJPAS \
  packages/rtl-objpas/src/inc/variants.pp
$PPC $COMMON -Fu$RTLWIN -Fu$OBJPAS -FU$OBJPAS \
  packages/rtl-objpas/src/inc/rtti.pp
$PPC $COMMON -Fu$RTLWIN -Fu$OBJPAS -FU$OBJPAS \
  packages/rtl-objpas/src/inc/system.timespan.pp
$PPC $COMMON -Fu$RTLWIN -Fu$OBJPAS -FU$OBJPAS \
  packages/rtl-objpas/src/inc/dateutils.pp
$PPC $COMMON -Fu$RTLWIN -Fu$OBJPAS -FU$OBJPAS \
  packages/rtl-objpas/src/inc/strutils.pp

# 4. rtl-generics units (depend on rtl-objpas)
# memoryexpanders -> strings -> hashes -> defaults -> helpers -> collections
# (see dist/win64/README.md v2 for full command list)

# 5. fcl-base contnrs
mkdir -p $FCLBASE
$PPC $COMMON -Fu$RTLWIN -Fu$OBJPAS -Fipackages/fcl-base/src -FU$FCLBASE \
  packages/fcl-base/src/contnrs.pp
```

## Build verification
Smoke test on `lazdev` compiled a 13-line program consuming sysutils +
dateutils + strutils + contnrs, producing a 208KB PE32+ console exe with
only kernel32+user32 imports.
