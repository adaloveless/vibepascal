# vibepascal Win64 Cross-Built Drop

Cross-compiled from `lazdev` (Linux x86_64) using FPC's internal PE-COFF assembler + internal linker.
**No mingw-w64 or external binutils required on the host.**

## Contents
- `bin/ppcx64.exe` — Win64-native vibepascal compiler (FPC 3.3.1 [2026/04/14], PE32+)
- `units/x86_64-win64/*.ppu` + `*.o` — Win64 RTL (90 units)

## Source snapshot
- Branch: `main`
- Includes the generic-method constraint-propagation fix landed in commit `a041fa7430` (tgeneric131 regression test passes on x86_64-linux; same compiler source is used to produce the Win64 binary here).

## Usage on Windows

Drop this tree alongside your FPC installation, e.g. `C:\vibepascal\`. Then:

```
C:\vibepascal\bin\ppcx64.exe -Fu"C:\vibepascal\units\x86_64-win64" stringx.pas
```

Or set `FPCDIR` to `C:\vibepascal` and your `fpc.cfg` search paths to pick up `units\x86_64-win64`.

## Build recipe (for reproduction on any Linux host)

```
# From vibepascal root:
make rtl_all CPU_TARGET=x86_64 OS_TARGET=win64 \
  FPC=./compiler/ppcx64 OPT="-Apecoff -Xi"

cd compiler
make compiler CPU_TARGET=x86_64 OS_TARGET=win64 \
  FPC=./ppcx64 OPT="-Apecoff -Xi"
```

`-Apecoff` = internal PE-COFF assembler writer
`-Xi` = internal linker

## Verification
```
file bin/ppcx64.exe
# PE32+ executable (console) x86-64 ..., for MS Windows
```

A minimal `writeln('hello')` program compiled with this compiler against the included RTL produces a valid Win64 PE32+ executable (verified on lazdev during build).

## Known-good use case
The primary target is Knox's commonx port: `TBetterObject.ToHolder<T: class>(): IHolder<T>` in `betterobject.pas:189` and ~20 dependent functions in `stringx.pas`. Prior FPC 3.2.2 ICE (EAccessViolation at $5B4A27) is gone; constraint inheritance now works.
