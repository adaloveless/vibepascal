# vibepascal Win64 Cross-Built Drop (v5)

Cross-compiled from `lazdev` (Linux x86_64) using FPC's internal PE-COFF
assembler + internal linker. **No mingw-w64 or external binutils required
on the host.** All binaries statically link RTL -- only kernel32.dll and
user32.dll are imported for typical code (oleaut32.dll when variants are
pulled in; ole32.dll when activex/COM is pulled in). Per God's
preference (dashboard mo35bv5w): large self-contained EXEs, not
dependency forests.

## Contents
- `bin/ppcx64.exe` -- Win64-native vibepascal compiler (FPC 3.3.1
  [2026/04/14], PE32+, ~5.0MB).
- `units/x86_64-win64/*.ppu` + `*.o` -- Win64 RTL (90 units).
- `packages/rtl-objpas/x86_64-win64/` -- variants, varutils, rtti,
  system.timespan, dateutils, strutils, fmtbcd.
- `packages/rtl-generics/x86_64-win64/` -- generics.{collections,
  defaults, helpers, hashes, memoryexpanders, strings}.
- `packages/fcl-base/x86_64-win64/` -- contnrs, syncobjs, inifiles.
- `packages/rtl-extra/x86_64-win64/` -- objects.
- `packages/winunits-base/x86_64-win64/` -- **tlhelp32**, **activex**
  (new in v5).

## What's new in v5 vs v4
v5 adds the two Windows API units Knox flagged on the dashboard after
trunk r5463 + FPC_commonx r5464 compile-chain progress:

- `tlhelp32.ppu` -- **desktop Win32/Win64** process/thread/module/heap
  walker. Imports from `kernel32.dll` using `stdcall` (note: this is
  NOT the `packages/winceunits/src/tlhelp32.pas` wrapper, which targets
  WinCE and imports from the non-existent-on-desktop `toolhelp.dll`).
  Provides ANSI (`PROCESSENTRY32`, `Process32First/Next`, etc.) and
  Wide (`PROCESSENTRY32W`, `Process32FirstW/NextW`, etc.) variants,
  matching Delphi's `Winapi.TlHelp32`. Source lives at
  `packages/winunits-base/src/tlhelp32.pp`.
- `activex.ppu` -- COM/OLE `IUnknown`/`IDispatch`/BSTR/VARIANT
  interop. Pulls `variants`, `ctypes`, `types`, `windows`.

## Source snapshot
- Repo: `github.com/adaloveless/vibepascal`
- Branch: `main`, commit embedded in tarball filename
  (`vibepascal-win64-<sha>-v5.tar.gz`).

## Usage on Windows
Extract alongside your FPC installation, e.g. `C:\vibepascal\`. Then:

```
C:\vibepascal\bin\ppcx64.exe ^
  -Fu"C:\vibepascal\units\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\rtl-objpas\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\rtl-generics\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\fcl-base\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\rtl-extra\x86_64-win64" ^
  -Fu"C:\vibepascal\packages\winunits-base\x86_64-win64" ^
  -Mdelphi stringx.pas
```

## Static linking
All resulting `.exe` binaries (including `ppcx64.exe` itself) statically
link the FPC RTL. No FPC DLL runtime dependencies -- only Windows system
DLLs are imported (kernel32, user32; oleaut32 + ole32 when the consumer
pulls variants or activex).

## Reproducible build recipe (on Linux with vibepascal compiler)

```sh
RTLWIN=$PWD/rtl/units/x86_64-win64
OBJPAS=$PWD/packages/rtl-objpas/units/x86_64-win64
WINUN=$PWD/packages/winunits-base/units/x86_64-win64
PPC=./compiler/ppcx64
COMMON="-Apecoff -Xi -Twin64"

# (v1-v4 steps unchanged -- see prior READMEs for RTL, rtl-objpas,
#  rtl-generics, fcl-base, rtl-extra builds.)

# 6. winunits-base (new in v5: tlhelp32 + activex)
mkdir -p $WINUN
$PPC $COMMON -Fu$RTLWIN -Fu$OBJPAS \
  -FU$WINUN packages/winunits-base/src/tlhelp32.pp
$PPC $COMMON -Fu$RTLWIN -Fu$OBJPAS -Fipackages/winunits-base/src \
  -FU$WINUN packages/winunits-base/src/activex.pp
```

## Build verification
Smoke test on `lazdev` compiled a 17-line program consuming windows +
tlhelp32 + activex + variants, calling `CreateToolhelp32Snapshot`,
`Process32First`, and `CoCreateGuid`. Result: 193KB PE32+ console exe,
imports kernel32 + user32 + ole32 + oleaut32. No toolhelp.dll import
(the WinCE wrapper's ghost dependency). Static-link confirmed.

## tlhelp32 choice of source
vibepascal ships TWO files named `tlhelp32`:

- `packages/winceunits/src/tlhelp32.pas` -- WinCE-only. Imports
  from `toolhelp.dll` (does not exist on desktop Windows), uses `cdecl`,
  `WCHAR` szExeFile. Do NOT use for Win64 desktop targets.
- `packages/winunits-base/src/tlhelp32.pp` -- **desktop Win32/Win64**.
  Imports from `kernel32.dll`, uses `stdcall`, provides ANSI + W variants.
  **This is what the v5 tarball's `tlhelp32.ppu` is built from.**

When you add the winunits-base unit directory to `-Fu`, the compiler
picks up the desktop version. Do not add the winceunits directory to
your Win64 search path.
